library(tidyverse)

# Ornek 1----
# -------------------------------------------------------------------------- ###
fiyatlar <- read_csv("./data/UBSprices.csv", 
                     show_col_types = FALSE)

# Bu veri seti 'tidy' degildir cunku her satirda 2 gozlem yer alir.
#
# 1. Veriyi her satirda spesifik bir yilda bir sehir olacak sekilde duzenleyin.
# 2. Pirinc fiyati icin tek bir degisken olusturun.
# 3. Yil icin bir degisken ekleyin.
# 
# head(fiyatlar)
##        sehir yil fiyat
## 1 Amsterdam 2003     9
## 2    Athens 2003    19
## 3  Auckland 2003     9
## 4   Bangkok 2003    25
## 5 Barcelona 2003    10
## 6    Berlin 2003    16


# Ornek 2----
# -------------------------------------------------------------------------- ###
anketler <- read_csv("./data/rcp-polls.csv", 
                     show_col_types = FALSE)

# Bu veri seti 'tidy' degildir cunku 
# 1. Date sutununda hem baslangic hem bitis tarihleri var. Bu ayrilmali
# 2. Sample sutununda 2 degisken var, Sayi ve LV-RV
# 3. Son 4 sutunda aday ve partiye gore oranlar var.

# head(anketler)
# # A tibble: 6 × 9
# poll     begin      end         size population  mo_e candidate party percentage
# <chr>    <date>     <date>     <dbl> <chr>      <dbl> <chr>     <chr>      <dbl>
# 1 Monmouth 2016-07-14 2016-07-16   688 LV           3.7 Clinton   D             45
# 2 Monmouth 2016-07-14 2016-07-16   688 LV           3.7 Trump     R             43
# 3 Monmouth 2016-07-14 2016-07-16   688 LV           3.7 Johnson   L              5
# 4 Monmouth 2016-07-14 2016-07-16   688 LV           3.7 Stein     G              1
# 5 CNN/ORC  2016-07-13 2016-07-16   872 RV           3.5 Clinton   D             42
# 6 CNN/ORC  2016-07-13 2016-07-16   872 RV           3.5 Trump     R             37


# Ornek 3----
# -------------------------------------------------------------------------- ###
havayollari <- read_csv("./data/airline-safety.csv", 
                        show_col_types = FALSE)

# # A tibble: 112 × 5
# airline               years     incidents fatal_accidents fatalities
# <chr>                 <chr>         <dbl>           <dbl>      <dbl>
# 1 Aer Lingus            1985-1999         2               0          0
# 2 Aer Lingus            2000-2014         0               0          0
# 3 Aeroflot              1985-1999        76              14        128
# 4 Aeroflot              2000-2014         6               1         88
# 5 Aerolineas Argentinas 1985-1999         6               0          0
# 6 Aerolineas Argentinas 2000-2014         1               0          0
# 7 Aeromexico            1985-1999         3               1         64
# 8 Aeromexico            2000-2014         5               0          0
# 9 Air Canada            1985-1999         2               0          0
# 10 Air Canada           2000-2014         2               0          0

