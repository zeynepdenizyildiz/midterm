library(tidyverse)

# -------------------------------------------------------------------------- ###
# data01----
# -------------------------------------------------------------------------- ###
# Two different tables in this file!
# Let's fix first one.
dataone <- readxl::read_xls("./data01.xls", range = "C4:M16") %>%
  pivot_longer(cols = "2014":"2023",
               names_to = "year",
               values_to = "weights") %>%
  pivot_wider(names_from = "Main expenditure group",
              values_from = "weights") %>%
  mutate(year = as.integer(year))

glimpse(dataone)

# What do these data show? What can we do with them?
# Note these values are CPI weights!


# -------------------------------------------------------------------------- ###
# data02----
# -------------------------------------------------------------------------- ###
datatwo <- readxl::read_xls("./data02.xls", range = "A5:AH18") %>%
  purrr::set_names(c("month", paste(c("tourism_income", "number_of_visitors",
                                      "average_expenditure"),
                                    rep(2012:2022, each = 3), sep = "."))) %>%
  separate(month, into = c("dropme", "month"), sep = " -") %>%
  select(-dropme) %>%
  mutate(across(-month, as.numeric)) %>%
  pivot_longer(-month,
               names_to = c("variable", "year"),
               names_sep = "\\.") %>%
  pivot_wider(names_from = "variable", values_from = "value") %>%
  mutate(year = as.integer(year))

glimpse(datatwo)

# Now what?

# -------------------------------------------------------------------------- ###
# data03----
# -------------------------------------------------------------------------- ###
datathree <- readxl::read_xlsx("./data03.xlsx", range = "B3:M8") %>%
  janitor::clean_names() %>%
  rename_with(.fn = ~str_remove_all(., "_percent"))

glimpse(datathree)

# ???

# -------------------------------------------------------------------------- ###
# data04----
# -------------------------------------------------------------------------- ###
datafour_raw <- read_csv("./data04.csv", show_col_types = FALSE)

glimpse(datafour_raw)

# Lots of different data types. Let's choose some of them.
datafour_raw %>% count(harvest_year)

datafour <- datafour_raw %>%
  select(total_cup_points, species, country_of_origin, altitude, harvest_year,
         aroma, flavor, aftertaste, acidity, color) %>%
  mutate(harvest_year = as.integer(harvest_year)) %>%
  drop_na(harvest_year) %>%
  mutate(color = as_factor(color),
         country_of_origin = as_factor(country_of_origin))


glimpse(datafour)

datafour %>% count(harvest_year)
datafour %>% count(color)
datafour %>% count(country_of_origin)

# Lots of possibilities for plots and hypothesis testing.


# -------------------------------------------------------------------------- ###
# data05----
# -------------------------------------------------------------------------- ###
datafive_raw <- data.table::fread("./data05.csv") %>%
  as_tibble()

glimpse(datafive_raw)


# Lots of observations let's sample
# datafive <- datafive_raw %>%
#   slice_sample(n = 100)

# Let's select some columns
datafive <- datafive_raw %>%
  select(company, title, location, yearsofexperience, yearsatcompany,
         basesalary, stockgrantvalue, bonus, gender,
         starts_with("Race"))

glimpse(datafive)


datafive %>% count(company, sort = TRUE)
datafive %>% count(gender, sort = TRUE) # Needs cleaning!!!

datafive <- datafive_raw %>%
  slice_sample(n = 200)
